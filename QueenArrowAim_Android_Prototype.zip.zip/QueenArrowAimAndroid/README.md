# Queen Arrow Aim — Android prototype (0.1.0)

This project is an experimental Android overlay prototype for a user-controlled aiming guide.

## Included
- Android MediaProjection consent flow and live display frame acquisition.
- Foreground service and floating overlay.
- Draggable start point and direction endpoint.
- Angle display and tick marks.
- User-tappable building markers and a rough line-intersection count.
- No game input injection, automation, memory reading, or game-file modification.

## Important limitations
This is NOT the fully automatic computer-vision version requested. MediaProjection acquires live screen frames, but this prototype currently discards each frame rather than running object recognition. It does not automatically identify the Archer Queen, buildings, defenses, walls, or the game's exact Giant Arrow trajectory. Building markers are manual. The line is a visual geometric aid and is not calibrated to game mechanics, perspective, camera scaling, or ability-specific behavior.

## Build
1. Open this folder in Android Studio (Ladybug or newer).
2. Install Android SDK 35.
3. Allow Gradle to sync dependencies.
4. Connect an Android phone and build/run the app.
5. On first use, grant overlay permission and Android screen-capture permission.

Android 14+ requires the user to grant screen capture for each session. Some manufacturers restrict overlays or background services. This is a source prototype, not a verified release APK.
