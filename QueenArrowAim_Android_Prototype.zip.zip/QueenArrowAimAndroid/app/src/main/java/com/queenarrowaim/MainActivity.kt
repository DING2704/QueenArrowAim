package com.queenarrowaim

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val requestCapture = 701
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(0xFF101916.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }

        root.addView(label("🏹 QUEEN ARROW AIM", 24f))
        root.addView(label("巨型箭矢 · 实时延长线辅助", 15f, 0xFFB8C9C2.toInt()))
        root.addView(label(
            "使用说明：开启悬浮窗权限和屏幕捕获后，切回游戏。拖动蓝色起点调整女王位置，拖动箭头端调整方向；点按画面标记箭矢路径上的建筑，估算穿透数量。",
            14f, 0xFFD7E5DF.toInt()
        ))
        val permissionButton = Button(this).apply {
            text = "① 开启悬浮窗权限"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val startButton = Button(this).apply {
            text = "② 开始屏幕捕获并显示瞄准线"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    text = "请先开启悬浮窗权限"
                } else {
                    startActivityForResult(projectionManager.createScreenCaptureIntent(), requestCapture)
                }
            }
        }
        val stopButton = Button(this).apply {
            text = "③ 停止辅助线"
            setOnClickListener { stopService(Intent(this@MainActivity, AimOverlayService::class.java)) }
        }
        root.addView(permissionButton)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(label("当前原型：实时屏幕捕获授权 + 可拖动悬浮瞄准线。建筑识别尚未自动化，需手动点选标记；不会自动释放技能或控制游戏。", 12f, 0xFFFFD18A.toInt()))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API; kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, AimOverlayService::class.java).apply {
                putExtra(AimOverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(AimOverlayService.EXTRA_DATA, data)
            }
            startForegroundService(service)
            finish()
        }
    }
}
