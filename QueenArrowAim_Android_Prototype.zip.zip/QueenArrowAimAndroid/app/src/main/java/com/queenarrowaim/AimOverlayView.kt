package com.queenarrowaim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class AimOverlayView(context: Context) : View(context) {
    private val line = Paint(3).apply { color = Color.rgb(255, 70, 65); strokeWidth = 5f; style = Paint.Style.STROKE }
    private val ticks = Paint(3).apply { color = Color.WHITE; strokeWidth = 2f }
    private val startPaint = Paint(3).apply { color = Color.rgb(50, 205, 255); style = Paint.Style.FILL }
    private val text = Paint(3).apply { color = Color.WHITE; textSize = 30f; setShadowLayer(5f, 1f, 1f, Color.BLACK) }
    private val buildingPaint = Paint(3).apply { color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 4f }
    private var sx = 0.28f
    private var sy = 0.52f
    private var angle = -0.12
    private var length = 0.72f
    private val marks = mutableListOf<Pair<Float, Float>>()
    private var draggingStart = false
    private var draggingEnd = false
    private var marking = false

    fun setStartPointNormalized(x: Float, y: Float) {
        sx = x.coerceIn(0.02f, 0.98f)
        sy = y.coerceIn(0.02f, 0.98f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x0 = sx * width
        val y0 = sy * height
        val dx = cos(angle).toFloat()
        val dy = sin(angle).toFloat()
        val x1 = x0 + dx * width * length
        val y1 = y0 + dy * width * length

        // Dashed extension ray
        line.pathEffect = android.graphics.DashPathEffect(floatArrayOf(18f, 12f), 0f)
        canvas.drawLine(x0, y0, x1, y1, line)
        line.pathEffect = null
        canvas.drawCircle(x0, y0, 17f, startPaint)
        canvas.drawCircle(x1, y1, 13f, line)

        // Angle ticks along the ray
        val perpX = -dy
        val perpY = dx
        for (i in 1..12) {
            val t = i / 12f
            val cx = x0 + (x1 - x0) * t
            val cy = y0 + (y1 - y0) * t
            val tick = if (i % 3 == 0) 17f else 9f
            canvas.drawLine(cx - perpX * tick, cy - perpY * tick,
                cx + perpX * tick, cy + perpY * tick, ticks)
        }

        marks.forEachIndexed { i, p ->
            val mx = p.first * width
            val my = p.second * height
            canvas.drawRect(mx - 20, my - 20, mx + 20, my + 20, buildingPaint)
            canvas.drawText("${i + 1}", mx + 23, my - 18, text)
        }
        val angleDeg = Math.toDegrees(angle).toInt()
        canvas.drawText("方向 ${angleDeg}°  ·  标记建筑 ${marks.size} 个", 24f, 52f, text)
        canvas.drawText("拖动蓝点=起点  拖动红端=方向  点建筑=标记/取消", 24f, 90f, text)
        canvas.drawText("穿过标记点：${countMarksOnRay(x0, y0, dx, dy, width * length)}", 24f, 128f, text)
    }

    private fun countMarksOnRay(x: Float, y: Float, dx: Float, dy: Float, maxDist: Float): Int {
        return marks.count {
            val mx = it.first * width - x
            val my = it.second * height - y
            val along = mx * dx + my * dy
            val cross = kotlin.math.abs(mx * dy - my * dx)
            along > 0 && along < maxDist && cross < 28f
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val x0 = sx * width
        val y0 = sy * height
        val x1 = x0 + cos(angle).toFloat() * width * length
        val y1 = y0 + sin(angle).toFloat() * width * length
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                draggingStart = hypot(x - x0, y - y0) < 55
                draggingEnd = hypot(x - x1, y - y1) < 65
                marking = !draggingStart && !draggingEnd
                if (marking) {
                    val nx = x / width
                    val ny = y / height
                    val index = marks.indexOfFirst { hypot((it.first - nx) * width, (it.second - ny) * height) < 35 }
                    if (index >= 0) marks.removeAt(index) else marks.add(Pair(nx, ny))
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (draggingStart) {
                    sx = (x / width).coerceIn(0.02f, 0.98f)
                    sy = (y / height).coerceIn(0.02f, 0.98f)
                } else if (draggingEnd) {
                    angle = atan2((y - y0).toDouble(), (x - x0).toDouble())
                    val distance = hypot((x - x0).toDouble(), (y - y0).toDouble())
                    length = (distance / width.toDouble()).coerceIn(0.1, 1.5).toFloat()
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                draggingStart = false; draggingEnd = false; marking = false
                return true
            }
        }
        return true
    }
}
