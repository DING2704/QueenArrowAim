package com.queenarrowaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AimOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        private const val CHANNEL = "queen_arrow_capture"
        private const val TAG = "QueenArrowAim"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: AimOverlayView? = null
    private var handleView: View? = null
    private var endHandleView: View? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var handleSizePx = 0
    private lateinit var windowManager: WindowManager

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped")
            releaseCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            (intent?.getParcelableExtra(EXTRA_DATA) as? Intent)
        }

        // Show the overlay independently of capture initialization. A capture failure
        // must not prevent the aiming guide from appearing on screen.
        try {
            showOverlay()
        } catch (e: Exception) {
            Log.e(TAG, "Unable to add overlay window", e)
            Toast.makeText(this, "悬浮窗创建失败：${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(
                    this,
                    41,
                    notification("瞄准线悬浮窗已显示；正在启动屏幕捕获"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(41, notification("瞄准线悬浮窗已显示"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start foreground service", e)
            Toast.makeText(this, "前台服务启动失败：${e.message}", Toast.LENGTH_LONG).show()
        }

        if (data != null && projection == null) {
            try {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(resultCode, data)
                projection?.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
                startScreenCapture()
                updateNotification("瞄准线已显示，屏幕捕获已启动")
            } catch (e: Exception) {
                Log.e(TAG, "Screen capture initialization failed; overlay remains visible", e)
                updateNotification("瞄准线已显示；屏幕捕获启动失败")
                Toast.makeText(this, "屏幕捕获启动失败，但瞄准线应仍显示：${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            updateNotification("瞄准线悬浮窗已显示")
        }
        return START_NOT_STICKY
    }

    private fun startScreenCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val frame = reader.acquireLatestImage()
            frame?.close()
        }, Handler(Looper.getMainLooper()))

        virtualDisplay = projection?.createVirtualDisplay(
            "QueenArrowAimCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        ) ?: throw IllegalStateException("VirtualDisplay 创建失败")
    }

    private fun showOverlay() {
        if (overlay != null) return
        // Full-screen drawing layer: it never consumes game touches.
        val view = AimOverlayView(this)
        val drawingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 1.0f
        }
        windowManager.addView(view, drawingParams)
        overlay = view

        // A separate small touchable handle lets the user move the start point
        // without making the full-screen drawing layer block the game.
        val density = resources.displayMetrics.density
        handleSizePx = (56f * density).toInt().coerceAtLeast(1)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val handle = object : View(this) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(50, 205, 255)
                style = Paint.Style.FILL
                setShadowLayer(8f, 0f, 2f, Color.BLACK)
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val c = width / 2f
                canvas.drawCircle(c, height / 2f, 17f * density, paint)
                paint.color = Color.WHITE
                paint.textSize = 10f * density
                canvas.drawText("拖动", c - 12f * density, height - 2f * density, paint)
                paint.color = Color.rgb(50, 205, 255)
            }
        }
        val hp = WindowManager.LayoutParams(
            handleSizePx,
            handleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (0.28f * metrics.widthPixels - handleSizePx / 2f).toInt()
            y = (0.52f * metrics.heightPixels - handleSizePx / 2f).toInt()
        }
        var downRawX = 0f
        var downRawY = 0f
        var downWindowX = 0
        var downWindowY = 0
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downWindowX = hp.x
                    downWindowY = hp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    hp.x = (downWindowX + event.rawX - downRawX).toInt()
                        .coerceIn(-handleSizePx / 2, metrics.widthPixels - handleSizePx / 2)
                    hp.y = (downWindowY + event.rawY - downRawY).toInt()
                        .coerceIn(-handleSizePx / 2, metrics.heightPixels - handleSizePx / 2)
                    try {
                        windowManager.updateViewLayout(handle, hp)
                        updatePointFromHandle(view, handle, isStart = true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Unable to move aim handle", e)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        windowManager.addView(handle, hp)
        handleView = handle
        handleParams = hp

        // Independent endpoint handle: moving it changes line direction and length.
        val endHandle = object : View(this) {
            private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(255, 90, 75)
                style = Paint.Style.FILL
                setShadowLayer(8f, 0f, 2f, Color.BLACK)
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                canvas.drawCircle(width / 2f, height / 2f, 17f * density, p)
                p.color = Color.WHITE
                p.textSize = 9f * density
                canvas.drawText("终点", width / 2f - 12f * density, height - 2f * density, p)
            }
        }
        val ep = WindowManager.LayoutParams(
            handleSizePx, handleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (0.98f * metrics.widthPixels - handleSizePx / 2f).toInt()
            y = (0.52f * metrics.heightPixels - handleSizePx / 2f).toInt()
        }
        var endDownX = 0f
        var endDownY = 0f
        var endWindowX = 0
        var endWindowY = 0
        endHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    endDownX = event.rawX; endDownY = event.rawY
                    endWindowX = ep.x; endWindowY = ep.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Clamp the endpoint center to the drawing overlay's real on-screen
                    // rectangle, not DisplayMetrics. DisplayMetrics can describe a
                    // different coordinate space in landscape / edge-to-edge mode.
                    val overlayLocation = IntArray(2)
                    view.getLocationOnScreen(overlayLocation)
                    val left = overlayLocation[0].toFloat()
                    val top = overlayLocation[1].toFloat()
                    val right = left + view.width.toFloat()
                    val bottom = top + view.height.toFloat()
                    val targetCenterX = (endWindowX + handleSizePx / 2f + event.rawX - endDownX)
                        .coerceIn(left, right)
                    val targetCenterY = (endWindowY + handleSizePx / 2f + event.rawY - endDownY)
                        .coerceIn(top, bottom)
                    ep.x = (targetCenterX - handleSizePx / 2f).toInt()
                    ep.y = (targetCenterY - handleSizePx / 2f).toInt()
                    try {
                        windowManager.updateViewLayout(endHandle, ep)
                        updatePointFromHandle(view, endHandle, isStart = false)
                    } catch (e: Exception) { Log.e(TAG, "Unable to move endpoint handle", e) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        windowManager.addView(endHandle, ep)
        endHandleView = endHandle

        // Align both touch handles to the drawing view's actual on-screen bounds.
        // This avoids display-metric vs. overlay-coordinate mismatches in landscape.
        view.post {
            positionHandleAtNormalized(handle, hp, view, 0.28f, 0.52f)
            positionHandleAtNormalized(endHandle, ep, view, 0.98f, 0.52f)
            view.setStartPointNormalized(0.28f, 0.52f)
            view.setEndPointNormalized(0.98f, 0.52f)
            view.invalidate()
        }
        Log.i(TAG, "Drawing overlay and draggable handles added successfully")
    }

    private fun updatePointFromHandle(view: AimOverlayView, handle: View, isStart: Boolean) {
        val overlayLocation = IntArray(2)
        val handleLocation = IntArray(2)
        view.getLocationOnScreen(overlayLocation)
        handle.getLocationOnScreen(handleLocation)
        val centerX = handleLocation[0] + handle.width / 2f
        val centerY = handleLocation[1] + handle.height / 2f
        val nx = ((centerX - overlayLocation[0]) / view.width.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        val ny = ((centerY - overlayLocation[1]) / view.height.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        if (isStart) view.setStartPointNormalized(nx, ny)
        else view.setEndPointNormalized(nx, ny)
    }

    private fun positionHandleAtNormalized(
        handle: View,
        params: WindowManager.LayoutParams,
        view: AimOverlayView,
        nx: Float,
        ny: Float
    ) {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        params.x = location[0] + (nx * view.width).toInt() - handleSizePx / 2
        params.y = location[1] + (ny * view.height).toInt() - handleSizePx / 2
        try {
            windowManager.updateViewLayout(handle, params)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to align aim handle", e)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Queen Arrow Aim",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Queen Arrow Aim 正在运行")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(41, notification(message))
    }

    private fun releaseCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection = null
    }

    override fun onDestroy() {
        releaseCapture()
        handleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Handle removal failed", e)
            }
        }
        handleView = null
        endHandleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Endpoint handle removal failed", e)
            }
        }
        endHandleView = null
        handleParams = null
        overlay?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Overlay removal failed", e)
            }
        }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
