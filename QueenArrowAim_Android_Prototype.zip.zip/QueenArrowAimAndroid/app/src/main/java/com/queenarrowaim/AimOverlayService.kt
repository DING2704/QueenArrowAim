package com.queenarrowaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AimOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        private const val CHANNEL = "queen_arrow_capture"
        private const val TAG = "QueenArrowAim"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: AimOverlayView? = null
    private var handleView: View? = null
    private var endHandleView: View? = null
    private var landingHandleView: View? = null
    private var landingToggleView: TextView? = null
    private var landingToggleParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var handleSizePx = 0
    private lateinit var windowManager: WindowManager

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped")
            releaseCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            (intent?.getParcelableExtra(EXTRA_DATA) as? Intent)
        }

        // Show the overlay independently of capture initialization. A capture failure
        // must not prevent the aiming guide from appearing on screen.
        try {
            showOverlay()
        } catch (e: Exception) {
            Log.e(TAG, "Unable to add overlay window", e)
            Toast.makeText(this, "悬浮窗创建失败：${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(
                    this,
                    41,
                    notification("瞄准线悬浮窗已显示；正在启动屏幕捕获"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(41, notification("瞄准线悬浮窗已显示"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start foreground service", e)
            Toast.makeText(this, "前台服务启动失败：${e.message}", Toast.LENGTH_LONG).show()
        }

        if (data != null && projection == null) {
            try {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(resultCode, data)
                projection?.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
                startScreenCapture()
                updateNotification("瞄准线已显示，屏幕捕获已启动")
            } catch (e: Exception) {
                Log.e(TAG, "Screen capture initialization failed; overlay remains visible", e)
                updateNotification("瞄准线已显示；屏幕捕获启动失败")
                Toast.makeText(this, "屏幕捕获启动失败，但瞄准线应仍显示：${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            updateNotification("瞄准线悬浮窗已显示")
        }
        return START_NOT_STICKY
    }

    private fun startScreenCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val frame = reader.acquireLatestImage()
            frame?.close()
        }, Handler(Looper.getMainLooper()))

        virtualDisplay = projection?.createVirtualDisplay(
            "QueenArrowAimCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        ) ?: throw IllegalStateException("VirtualDisplay 创建失败")
    }

    private fun showOverlay() {
        if (overlay != null) return
        // Full-screen drawing layer: it never consumes game touches.
        val view = AimOverlayView(this)
        val drawingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 1.0f
        }
        windowManager.addView(view, drawingParams)
        overlay = view

        // A separate small touchable handle lets the user move the start point
        // without making the full-screen drawing layer block the game.
        val density = resources.displayMetrics.density
        handleSizePx = (56f * density).toInt().coerceAtLeast(1)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val handle = object : View(this) {
            private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(155, 50, 205, 255)
                style = Paint.Style.STROKE
                strokeWidth = 2.5f * density
            }
            private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(50, 205, 255)
                style = Paint.Style.FILL
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val c = width / 2f
                val cy = height / 2f
                canvas.drawCircle(c, cy, 14f * density, ring)
                canvas.drawCircle(c, cy, 4.5f * density, dot)
            }
        }
        val hp = WindowManager.LayoutParams(
            handleSizePx,
            handleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (0.28f * metrics.widthPixels - handleSizePx / 2f).toInt()
            y = (0.52f * metrics.heightPixels - handleSizePx / 2f).toInt()
        }
        var downRawX = 0f
        var downRawY = 0f
        var downWindowX = 0
        var downWindowY = 0
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downWindowX = hp.x
                    downWindowY = hp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Clamp the blue start handle to the actual drawing overlay bounds.
                    // Do not use DisplayMetrics here: in landscape / immersive game mode
                    // those dimensions can describe a different coordinate space.
                    val overlayLocation = IntArray(2)
                    view.getLocationOnScreen(overlayLocation)
                    val left = overlayLocation[0].toFloat()
                    val top = overlayLocation[1].toFloat()
                    val right = left + view.width.toFloat()
                    val bottom = top + view.height.toFloat()
                    val targetCenterX = (downWindowX + handleSizePx / 2f + event.rawX - downRawX)
                        .coerceIn(left, right)
                    val targetCenterY = (downWindowY + handleSizePx / 2f + event.rawY - downRawY)
                        .coerceIn(top, bottom)
                    hp.x = (targetCenterX - handleSizePx / 2f).toInt()
                    hp.y = (targetCenterY - handleSizePx / 2f).toInt()
                    try {
                        windowManager.updateViewLayout(handle, hp)
                        updatePointFromHandle(view, handle, isStart = true)
                    } catch (e: Exception) {
                        Log.e(TAG, "Unable to move blue start handle", e)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        windowManager.addView(handle, hp)
        handleView = handle
        handleParams = hp

        // Independent endpoint handle: moving it changes line direction and length.
        val endHandle = object : View(this) {
            private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(190, 255, 255, 255)
                style = Paint.Style.STROKE
                strokeWidth = 2.5f * density
            }
            private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val c = width / 2f
                val cy = height / 2f
                canvas.drawCircle(c, cy, 14f * density, ring)
                canvas.drawCircle(c, cy, 4.5f * density, dot)
            }
        }
        val ep = WindowManager.LayoutParams(
            handleSizePx, handleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (0.98f * metrics.widthPixels - handleSizePx / 2f).toInt()
            y = (0.52f * metrics.heightPixels - handleSizePx / 2f).toInt()
        }
        var endDownX = 0f
        var endDownY = 0f
        var endWindowX = 0
        var endWindowY = 0
        endHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    endDownX = event.rawX; endDownY = event.rawY
                    endWindowX = ep.x; endWindowY = ep.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Clamp the endpoint center to the drawing overlay's real on-screen
                    // rectangle, not DisplayMetrics. DisplayMetrics can describe a
                    // different coordinate space in landscape / edge-to-edge mode.
                    val overlayLocation = IntArray(2)
                    view.getLocationOnScreen(overlayLocation)
                    val left = overlayLocation[0].toFloat()
                    val top = overlayLocation[1].toFloat()
                    val right = left + view.width.toFloat()
                    val bottom = top + view.height.toFloat()
                    val targetCenterX = (endWindowX + handleSizePx / 2f + event.rawX - endDownX)
                        .coerceIn(left, right)
                    val targetCenterY = (endWindowY + handleSizePx / 2f + event.rawY - endDownY)
                        .coerceIn(top, bottom)
                    ep.x = (targetCenterX - handleSizePx / 2f).toInt()
                    ep.y = (targetCenterY - handleSizePx / 2f).toInt()
                    try {
                        windowManager.updateViewLayout(endHandle, ep)
                        updatePointFromHandle(view, endHandle, isStart = false)
                    } catch (e: Exception) { Log.e(TAG, "Unable to move endpoint handle", e) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        windowManager.addView(endHandle, ep)
        endHandleView = endHandle

        // Independent queen landing marker handle. Drag to place; use the
        // separate toggle control to lock/unlock and enable touch-through.
        val landingHandle = object : View(this) {
            private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(190, 255, 190, 55)
                style = Paint.Style.STROKE
                strokeWidth = 3f * density
            }
            private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(255, 190, 55)
                style = Paint.Style.FILL
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val c = width / 2f
                val cy = height / 2f
                canvas.drawCircle(c, cy, 25f * density, ring)
                canvas.drawCircle(c, cy, 5f * density, dot)
            }
        }
        val lp = WindowManager.LayoutParams(
            handleSizePx, handleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        var landingDownX = 0f
        var landingDownY = 0f
        var landingWindowX = 0
        var landingWindowY = 0
        var landingMoved = false
        landingHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    landingDownX = event.rawX
                    landingDownY = event.rawY
                    landingWindowX = lp.x
                    landingWindowY = lp.y
                    landingMoved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (view.isLandingLocked()) return@setOnTouchListener true
                    val dx = event.rawX - landingDownX
                    val dy = event.rawY - landingDownY
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 6f) landingMoved = true
                    val overlayLocation = IntArray(2)
                    view.getLocationOnScreen(overlayLocation)
                    val left = overlayLocation[0].toFloat()
                    val top = overlayLocation[1].toFloat()
                    val right = left + view.width.toFloat()
                    val bottom = top + view.height.toFloat()
                    val centerX = (landingWindowX + handleSizePx / 2f + dx).coerceIn(left, right)
                    val centerY = (landingWindowY + handleSizePx / 2f + dy).coerceIn(top, bottom)
                    lp.x = (centerX - handleSizePx / 2f).toInt()
                    lp.y = (centerY - handleSizePx / 2f).toInt()
                    try {
                        windowManager.updateViewLayout(landingHandle, lp)
                        updateLandingFromHandle(view, landingHandle)
                    } catch (e: Exception) {
                        Log.e(TAG, "Unable to move queen landing marker", e)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    // A tap on the marker itself no longer toggles lock. The
                    // dedicated toggle control does that, so a locked marker can
                    // become fully touch-through for game deployment.
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        windowManager.addView(landingHandle, lp)
        landingHandleView = landingHandle

        // A separate compact control remains touchable while the locked landing
        // marker window is FLAG_NOT_TOUCHABLE, allowing game touches to pass through
        // the yellow ring and its center without losing the ability to unlock.
        val toggle = TextView(this).apply {
            text = "落点锁定"
            textSize = 13f
            setTextColor(Color.rgb(28, 35, 44))
            setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            setPadding((12 * density).toInt(), (7 * density).toInt(),
                (12 * density).toInt(), (7 * density).toInt())
            setBackgroundColor(Color.argb(225, 238, 242, 246))
        }
        val tp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (12 * density).toInt()
        }
        toggle.setOnClickListener {
            val locked = !view.isLandingLocked()
            view.setLandingLocked(locked)
            lp.flags = if (locked) {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            }
            try { windowManager.updateViewLayout(landingHandle, lp) }
            catch (e: Exception) { Log.e(TAG, "Unable to update landing touch mode", e) }
            toggle.text = if (locked) "落点已锁定 · 解锁" else "落点未锁定 · 锁定"
            toggle.setBackgroundColor(
                if (locked) Color.argb(230, 205, 238, 218)
                else Color.argb(230, 250, 232, 195)
            )
            landingHandle.invalidate()
            Toast.makeText(this, if (locked) "落点已锁定，游戏触控可穿透" else "落点已解锁，可拖动", Toast.LENGTH_SHORT).show()
        }
        windowManager.addView(toggle, tp)
        landingToggleView = toggle
        landingToggleParams = tp

        // Align all three handles to the drawing view's actual on-screen bounds. to the drawing view's actual on-screen bounds.
        // This avoids display-metric vs. overlay-coordinate mismatches in landscape.
        view.post {
            positionHandleAtNormalized(handle, hp, view, 0.28f, 0.52f)
            positionHandleAtNormalized(endHandle, ep, view, 0.98f, 0.52f)
            positionHandleAtNormalized(landingHandle, lp, view, 0.50f, 0.50f)
            view.setLandingPointNormalized(0.50f, 0.50f)
            view.setStartPointNormalized(0.28f, 0.52f)
            view.setEndPointNormalized(0.98f, 0.52f)
            view.invalidate()
        }
        Log.i(TAG, "Drawing overlay and draggable handles added successfully")
    }

    private fun updatePointFromHandle(view: AimOverlayView, handle: View, isStart: Boolean) {
        val overlayLocation = IntArray(2)
        val handleLocation = IntArray(2)
        view.getLocationOnScreen(overlayLocation)
        handle.getLocationOnScreen(handleLocation)
        val centerX = handleLocation[0] + handle.width / 2f
        val centerY = handleLocation[1] + handle.height / 2f
        val nx = ((centerX - overlayLocation[0]) / view.width.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        val ny = ((centerY - overlayLocation[1]) / view.height.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        if (isStart) view.setStartPointNormalized(nx, ny)
        else view.setEndPointNormalized(nx, ny)
    }

    private fun updateLandingFromHandle(view: AimOverlayView, handle: View) {
        val overlayLocation = IntArray(2)
        val handleLocation = IntArray(2)
        view.getLocationOnScreen(overlayLocation)
        handle.getLocationOnScreen(handleLocation)
        val centerX = handleLocation[0] + handle.width / 2f
        val centerY = handleLocation[1] + handle.height / 2f
        val nx = ((centerX - overlayLocation[0]) / view.width.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        val ny = ((centerY - overlayLocation[1]) / view.height.coerceAtLeast(1))
            .coerceIn(0.01f, 0.99f)
        view.setLandingPointNormalized(nx, ny)
    }

    private fun positionHandleAtNormalized(
        handle: View,
        params: WindowManager.LayoutParams,
        view: AimOverlayView,
        nx: Float,
        ny: Float
    ) {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        params.x = location[0] + (nx * view.width).toInt() - handleSizePx / 2
        params.y = location[1] + (ny * view.height).toInt() - handleSizePx / 2
        try {
            windowManager.updateViewLayout(handle, params)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to align aim handle", e)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Queen Arrow Aim",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Queen Arrow Aim 正在运行")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(41, notification(message))
    }

    private fun releaseCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection = null
    }

    override fun onDestroy() {
        releaseCapture()
        handleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Handle removal failed", e)
            }
        }
        handleView = null
        endHandleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Endpoint handle removal failed", e)
            }
        }
        endHandleView = null
        landingHandleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Landing handle removal failed", e)
            }
        }
        landingHandleView = null
        landingToggleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Landing toggle removal failed", e)
            }
        }
        landingToggleView = null
        landingToggleParams = null
        handleParams = null
        overlay?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Overlay removal failed", e)
            }
        }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
