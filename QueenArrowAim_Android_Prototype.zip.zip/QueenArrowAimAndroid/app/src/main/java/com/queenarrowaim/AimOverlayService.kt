package com.queenarrowaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AimOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        private const val CHANNEL = "queen_arrow_capture"
        private const val TAG = "QueenArrowAim"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: AimOverlayView? = null
    private lateinit var windowManager: WindowManager

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped")
            releaseCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            (intent?.getParcelableExtra(EXTRA_DATA) as? Intent)
        }

        // Show the overlay independently of capture initialization. A capture failure
        // must not prevent the aiming guide from appearing on screen.
        try {
            showOverlay()
        } catch (e: Exception) {
            Log.e(TAG, "Unable to add overlay window", e)
            Toast.makeText(this, "悬浮窗创建失败：${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(
                    this,
                    41,
                    notification("瞄准线悬浮窗已显示；正在启动屏幕捕获"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(41, notification("瞄准线悬浮窗已显示"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start foreground service", e)
            Toast.makeText(this, "前台服务启动失败：${e.message}", Toast.LENGTH_LONG).show()
        }

        if (data != null && projection == null) {
            try {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(resultCode, data)
                projection?.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
                startScreenCapture()
                updateNotification("瞄准线已显示，屏幕捕获已启动")
            } catch (e: Exception) {
                Log.e(TAG, "Screen capture initialization failed; overlay remains visible", e)
                updateNotification("瞄准线已显示；屏幕捕获启动失败")
                Toast.makeText(this, "屏幕捕获启动失败，但瞄准线应仍显示：${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            updateNotification("瞄准线悬浮窗已显示")
        }
        return START_NOT_STICKY
    }

    private fun startScreenCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val frame = reader.acquireLatestImage()
            frame?.close()
        }, Handler(Looper.getMainLooper()))

        virtualDisplay = projection?.createVirtualDisplay(
            "QueenArrowAimCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        ) ?: throw IllegalStateException("VirtualDisplay 创建失败")
    }

    private fun showOverlay() {
        if (overlay != null) return
        val view = AimOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Keep the guide visible while allowing taps to pass through to the game.
            alpha = 1.0f
        }
        windowManager.addView(view, params)
        overlay = view
        view.invalidate()
        Log.i(TAG, "Overlay window added successfully")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Queen Arrow Aim",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Queen Arrow Aim 正在运行")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(41, notification(message))
    }

    private fun releaseCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection = null
    }

    override fun onDestroy() {
        releaseCapture()
        overlay?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.w(TAG, "Overlay removal failed", e)
            }
        }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
